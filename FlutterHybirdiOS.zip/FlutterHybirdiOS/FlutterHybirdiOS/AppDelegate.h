//
//  AppDelegate.h
//  FlutterHybirdiOS
//
//  Created by Jason on 2022/6/19.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

