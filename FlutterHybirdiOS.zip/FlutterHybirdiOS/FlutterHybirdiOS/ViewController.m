//
//  ViewController.m
//  FlutterHybirdiOS
//
//  Created by Jason on 2022/6/19.
//

#import "ViewController.h"
#import <Flutter/Flutter.h>

@interface ViewController ()
@property(nonatomic,assign) BOOL useEventChannel;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(showMessage:) name:@"showMessage" object:nil];
    
}
- (void)showMessage:(NSNotification*)noti{
    id params = noti.object;
    self.showLabel.text = [NSString stringWithFormat:@"来自Dart:%@",params];
}

//加载flutter界面
- (void)test {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button addTarget:self action:@selector(handleButtonAction) forControlEvents:UIControlEventTouchUpInside];
    [button setTitle:@"加载Flutter" forState:UIControlStateNormal];
    [button setBackgroundColor:[UIColor blueColor]];
    button.frame = CGRectMake(100, 100, 160, 60);
    [self.view addSubview:button];
}
#pragma MARK:- 加载flutter
//- (void)handleButtonAction {
//    FlutterViewController *fvc = [FlutterViewController new];
//    [fvc setInitialRoute:@"route2"];
//    [self presentViewController:fvc animated:true completion:^{
//            NSLog(@"加载flutter页面成功");
//    }];
//}
- (IBAction)editChange:(UITextField *)sender {
    [[NSNotificationCenter defaultCenter] postNotificationName:@"sendMessage" object:@{@"message": sender.text,@"useEventChannel":self.useEventChannel? @"true":@"false"}];
}

- (IBAction)onSwitch:(UISwitch *)sender {
    UISwitch *uSwitch = sender;
    if (uSwitch.isOn) {
        self.useEventChannel = true;
    } else {
        self.useEventChannel = false;
    }
}

- (void)handleButtonAction {
    //以一个完整页面打开Flutter模块
    FlutterViewController *flutterViewController = [FlutterViewController new];
    
    [flutterViewController setInitialRoute:@"{name:'devio',dataList:['aa','bb',''cc]}"];
    
    [self presentViewController:flutterViewController animated:true completion:nil];
    self.view=flutterViewController.view;
}

@end
