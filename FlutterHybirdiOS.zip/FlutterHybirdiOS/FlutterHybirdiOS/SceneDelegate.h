//
//  SceneDelegate.h
//  FlutterHybirdiOS
//
//  Created by Jason on 2022/6/19.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

