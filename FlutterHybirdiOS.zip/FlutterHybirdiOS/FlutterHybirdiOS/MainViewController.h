//
//  MainViewController.h
//  FlutterHybirdiOS
//
//  Created by Jason on 2022/6/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MainViewController : UIViewController
@property(strong,nonatomic)NSString *inputParams;
@end

NS_ASSUME_NONNULL_END
