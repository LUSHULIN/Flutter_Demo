//
//  ViewController.h
//  FlutterHybirdiOS
//
//  Created by Jason on 2022/6/19.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *showLabel;

@end

